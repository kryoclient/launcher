const React = window.React;
const { useState, useEffect } = React;

const DISCORD_CLIENT_ID = "1129482123891724398";
let socket = null;
let reconnectTimer = null;

function sendDiscordActivity(api, inGameVersion = null) {
  const isEnabled = api.storage.get("rpc_enabled", true);
  if (!isEnabled) {
    clearDiscordActivity();
    return;
  }

  const showProfile = api.storage.get("showProfile", true);
  const showVersion = api.storage.get("showVersion", true);
  const customDetails = api.storage.get(
    "customDetails",
    "Играет в KryoClient",
  );

  const profile = api.game.getSelectedProfile();
  const version = api.game.getSelectedVersion();

  let details = customDetails;
  let state = "";

  if (inGameVersion) {
    details = "В игре Minecraft " + inGameVersion;
    if (showProfile && profile) {
      state = "Ник: " + profile.username;
    }
  } else {
    if (showProfile && profile) {
      state = "Профиль: " + profile.username;
    }
    if (showVersion && version) {
      state += (state ? " • " : "") + version.id;
    }
  }

  const payload = {
    cmd: "SET_ACTIVITY",
    args: {
      pid: 1,
      activity: {
        details: details || "KryoClient",
        state: state || "В главном меню",
        timestamps: {
          start: Math.floor(Date.now() / 1000),
        },
        assets: {
          large_image: "kryoclient_logo",
          large_text: "KryoClient",
        },
      },
    },
    nonce: String(Date.now()),
  };

  if (socket && socket.readyState === WebSocket.OPEN) {
    try {
      socket.send(JSON.stringify(payload));
    } catch {
      // Ignore socket errors
    }
  } else {
    connectToDiscordRpc(() => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify(payload));
      }
    });
  }
}

function connectToDiscordRpc(onReady) {
  if (
    socket &&
    (socket.readyState === WebSocket.OPEN ||
      socket.readyState === WebSocket.CONNECTING)
  ) {
    return;
  }

  try {
    socket = new WebSocket(
      `ws://127.0.0.1:6463/?v=1&client_id=${DISCORD_CLIENT_ID}`,
    );

    socket.onopen = () => {
      if (onReady) onReady();
    };

    socket.onmessage = (event) => {
      // Heartbeat or event response
    };

    socket.onerror = () => {
      if (socket) socket.close();
    };

    socket.onclose = () => {
      socket = null;
    };
  } catch {
    socket = null;
  }
}

function clearDiscordActivity() {
  if (socket) {
    try {
      socket.close();
    } catch {}
    socket = null;
  }
}

function DiscordRpcWidget({ api }) {
  const [enabled, setEnabled] = useState(() =>
    api.storage.get("rpc_enabled", true),
  );

  const KryoClient = window.KryoClient;
  const Button = KryoClient?.ui?.Button || KryoClient?.Button || "button";

  useEffect(() => {
    sendDiscordActivity(api);

    const unsub = api.events.on("addon:discord-rpc:configChange", () => {
      sendDiscordActivity(api);
    });

    return () => {
      unsub();
      clearDiscordActivity();
    };
  }, [api]);

  const toggle = () => {
    const next = !enabled;
    setEnabled(next);
    api.storage.set("rpc_enabled", next);
    if (next) {
      sendDiscordActivity(api);
      api.ui.showToast("Discord RPC включен", "success");
    } else {
      clearDiscordActivity();
      api.ui.showToast("Discord RPC выключен", "info");
    }
  };

  return React.createElement(
    Button,
    {
      variant: "outline",
      size: "sm",
      type: "button",
      onClick: toggle,
      title: enabled
        ? "Discord RPC активен (нажмите, чтобы выключить)"
        : "Discord RPC выключен (нажмите, чтобы включить)",
      className:
        "border-border/40 bg-card/40 flex h-9 cursor-pointer items-center gap-2 px-3 text-xs backdrop-blur-sm transition-all font-semibold whitespace-nowrap " +
        (enabled
          ? "hover:border-[#5865F2]/50 hover:bg-[#5865F2]/10 text-foreground"
          : "hover:border-border/60 hover:bg-accent/40 text-muted-foreground opacity-60"),
    },
    React.createElement(
      "svg",
      {
        viewBox: "0 0 24 24",
        width: 15,
        height: 15,
        fill: "currentColor",
        className: enabled
          ? "text-[#5865F2] shrink-0"
          : "text-muted-foreground shrink-0",
      },
      React.createElement("path", {
        d: "M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z",
      }),
    ),
    "Discord",
    React.createElement("span", {
      className:
        "h-1.5 w-1.5 rounded-full " +
        (enabled
          ? "bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]"
          : "bg-muted-foreground/40"),
    }),
  );
}

export default {
  manifest: {
    id: "discord-rpc",
    name: "Discord Rich Presence",
    version: "1.2.0",
    description:
      "Отображает статус в Discord: версию Minecraft, выбранный профиль и время игры (100% модульный, без утяжеления лаунчера).",
    author: "KryoClient Team",
    category: "integration",
    permissions: [
      "game:lifecycle",
      "game:profiles",
      "ui:slots",
      "storage:local",
      "network:fetch",
    ],
    tags: ["discord", "rpc", "status", "social"],
  },
  activate(api) {
    api.ui.registerSlot("header.actions", "rpc-btn", DiscordRpcWidget, 10);
    sendDiscordActivity(api);

    api.services.provide("discord-presence", {
      getStatus: () => api.storage.get("rpc_enabled", true),
      setStatusText: (text) => {
        api.storage.set("customDetails", text);
        sendDiscordActivity(api);
      },
    });

    api.game.onBeforeLaunch((ctx) => {
      sendDiscordActivity(api, ctx.versionId);
    });
  },
  deactivate(api) {
    clearDiscordActivity();
    api.ui.unregisterSlot("rpc-btn");
  },
};
